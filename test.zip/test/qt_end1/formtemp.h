#ifndef FORMTEMP_H
#define FORMTEMP_H

#include <QWidget>
#include <QChartView>
#include <QLineSeries>
#include <QValueAxis>
#include <QTimer>
/*  必需添加命名空间 */
QT_CHARTS_USE_NAMESPACE

namespace Ui {
class FormTemp;
}

class FormTemp : public QWidget
{
    Q_OBJECT

public:
    explicit FormTemp(QWidget *parent = nullptr);
    ~FormTemp();

private slots:
    void timerTimeOut();

private:
    QLineSeries *line_1;  //温度第一条线

    QLineSeries *line_2;

    QLineSeries *line_3;

    Ui::FormTemp *ui;
};

#endif // FORMTEMP_H
