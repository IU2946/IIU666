/********************************************************************************
** Form generated from reading UI file 'formhum.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORMHUM_H
#define UI_FORMHUM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>
#include "qchartview.h"

QT_BEGIN_NAMESPACE

class Ui_FormHum
{
public:
    QChartView *graphicsView;

    void setupUi(QWidget *FormHum)
    {
        if (FormHum->objectName().isEmpty())
            FormHum->setObjectName(QString::fromUtf8("FormHum"));
        FormHum->resize(954, 484);
        graphicsView = new QChartView(FormHum);
        graphicsView->setObjectName(QString::fromUtf8("graphicsView"));
        graphicsView->setGeometry(QRect(2, 2, 950, 480));

        retranslateUi(FormHum);

        QMetaObject::connectSlotsByName(FormHum);
    } // setupUi

    void retranslateUi(QWidget *FormHum)
    {
        FormHum->setWindowTitle(QCoreApplication::translate("FormHum", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class FormHum: public Ui_FormHum {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORMHUM_H
