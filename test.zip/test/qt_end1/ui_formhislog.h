/********************************************************************************
** Form generated from reading UI file 'formhislog.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORMHISLOG_H
#define UI_FORMHISLOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FormHisLog
{
public:
    QTextEdit *textEdit;
    QPushButton *pushButton;

    void setupUi(QWidget *FormHisLog)
    {
        if (FormHisLog->objectName().isEmpty())
            FormHisLog->setObjectName(QString::fromUtf8("FormHisLog"));
        FormHisLog->resize(650, 500);
        textEdit = new QTextEdit(FormHisLog);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(10, 50, 630, 440));
        QFont font;
        font.setPointSize(14);
        textEdit->setFont(font);
        pushButton = new QPushButton(FormHisLog);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(20, 10, 131, 31));
        pushButton->setFont(font);

        retranslateUi(FormHisLog);

        QMetaObject::connectSlotsByName(FormHisLog);
    } // setupUi

    void retranslateUi(QWidget *FormHisLog)
    {
        FormHisLog->setWindowTitle(QCoreApplication::translate("FormHisLog", "Form", nullptr));
        pushButton->setText(QCoreApplication::translate("FormHisLog", "\346\270\205\351\231\244\346\227\245\345\277\227", nullptr));
    } // retranslateUi

};

namespace Ui {
    class FormHisLog: public Ui_FormHisLog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORMHISLOG_H
