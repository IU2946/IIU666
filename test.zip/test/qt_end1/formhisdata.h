#ifndef FORMHISDATA_H
#define FORMHISDATA_H

#include <QWidget>

namespace Ui {
class FormHisData;
}

class FormHisData : public QWidget
{
    Q_OBJECT

public:
    explicit FormHisData(QWidget *parent = nullptr);
    ~FormHisData();

private slots:
    void on_pushButton_clicked();

private:
    Ui::FormHisData *ui;
};

#endif // FORMHISDATA_H
