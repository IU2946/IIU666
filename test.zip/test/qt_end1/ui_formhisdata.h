/********************************************************************************
** Form generated from reading UI file 'formhisdata.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORMHISDATA_H
#define UI_FORMHISDATA_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FormHisData
{
public:
    QPushButton *pushButton;
    QTextEdit *textEdit;

    void setupUi(QWidget *FormHisData)
    {
        if (FormHisData->objectName().isEmpty())
            FormHisData->setObjectName(QString::fromUtf8("FormHisData"));
        FormHisData->resize(650, 500);
        pushButton = new QPushButton(FormHisData);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(20, 10, 131, 31));
        QFont font;
        font.setPointSize(14);
        pushButton->setFont(font);
        textEdit = new QTextEdit(FormHisData);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(20, 50, 611, 441));

        retranslateUi(FormHisData);

        QMetaObject::connectSlotsByName(FormHisData);
    } // setupUi

    void retranslateUi(QWidget *FormHisData)
    {
        FormHisData->setWindowTitle(QCoreApplication::translate("FormHisData", "Form", nullptr));
        pushButton->setText(QCoreApplication::translate("FormHisData", "\346\270\205\351\231\244\345\216\206\345\217\262\350\256\260\345\275\225", nullptr));
    } // retranslateUi

};

namespace Ui {
    class FormHisData: public Ui_FormHisData {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORMHISDATA_H
