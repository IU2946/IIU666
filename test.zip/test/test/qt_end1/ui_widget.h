/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QLabel *back_label;
    QLabel *label;
    QFrame *frame;
    QPushButton *pushButton_begin;
    QPushButton *pushButton_off;
    QPushButton *pushButton_temp;
    QPushButton *pushButton_hum;
    QPushButton *pushButton_ppm;
    QPushButton *pushButton_fire;
    QPushButton *pushButton_history;
    QPushButton *pushButton_log;
    QLabel *label_time;
    QFrame *frame_date_1;
    QLabel *label_date_a_1;
    QLabel *label_date_a_2;
    QLabel *label_date_a_3;
    QLabel *label_date_a_4;
    QTextEdit *textEdit_a_1;
    QTextEdit *textEdit_a_3;
    QTextEdit *textEdit_a_2;
    QTextEdit *textEdit_a_4;
    QFrame *frame_date_2;
    QLabel *label_date_b_1;
    QLabel *label_date_b_2;
    QLabel *label_date_b_3;
    QLabel *label_date_b_4;
    QTextEdit *textEdit_b_1;
    QTextEdit *textEdit_b_2;
    QTextEdit *textEdit_b_3;
    QTextEdit *textEdit_b_4;
    QFrame *frame_date_3;
    QLabel *label_date_c_1;
    QLabel *label_date_c_2;
    QLabel *label_date_c_3;
    QLabel *label_date_c_4;
    QTextEdit *textEdit_c_1;
    QTextEdit *textEdit_c_2;
    QTextEdit *textEdit_c_3;
    QTextEdit *textEdit_c_4;
    QFrame *frame_a_1;
    QLabel *label_a_1;
    QLabel *label_a_2;
    QPushButton *set_a;
    QPushButton *set_b;
    QPushButton *set_c;
    QTextEdit *textEdit;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(900, 500);
        QFont font;
        font.setPointSize(14);
        Widget->setFont(font);
        back_label = new QLabel(Widget);
        back_label->setObjectName(QString::fromUtf8("back_label"));
        back_label->setGeometry(QRect(0, 0, 900, 500));
        label = new QLabel(Widget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 900, 500));
        label->setStyleSheet(QString::fromUtf8("background-image: url(:/image/test.png);"));
        frame = new QFrame(Widget);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(30, 20, 111, 431));
        frame->setStyleSheet(QString::fromUtf8(""));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        pushButton_begin = new QPushButton(frame);
        pushButton_begin->setObjectName(QString::fromUtf8("pushButton_begin"));
        pushButton_begin->setGeometry(QRect(20, 20, 75, 30));
        pushButton_off = new QPushButton(frame);
        pushButton_off->setObjectName(QString::fromUtf8("pushButton_off"));
        pushButton_off->setGeometry(QRect(20, 370, 75, 30));
        pushButton_temp = new QPushButton(frame);
        pushButton_temp->setObjectName(QString::fromUtf8("pushButton_temp"));
        pushButton_temp->setGeometry(QRect(20, 70, 75, 30));
        pushButton_hum = new QPushButton(frame);
        pushButton_hum->setObjectName(QString::fromUtf8("pushButton_hum"));
        pushButton_hum->setGeometry(QRect(20, 120, 75, 30));
        pushButton_ppm = new QPushButton(frame);
        pushButton_ppm->setObjectName(QString::fromUtf8("pushButton_ppm"));
        pushButton_ppm->setGeometry(QRect(20, 170, 75, 30));
        pushButton_fire = new QPushButton(frame);
        pushButton_fire->setObjectName(QString::fromUtf8("pushButton_fire"));
        pushButton_fire->setGeometry(QRect(20, 220, 75, 30));
        pushButton_history = new QPushButton(frame);
        pushButton_history->setObjectName(QString::fromUtf8("pushButton_history"));
        pushButton_history->setGeometry(QRect(20, 270, 75, 30));
        pushButton_log = new QPushButton(frame);
        pushButton_log->setObjectName(QString::fromUtf8("pushButton_log"));
        pushButton_log->setGeometry(QRect(20, 320, 75, 30));
        label_time = new QLabel(Widget);
        label_time->setObjectName(QString::fromUtf8("label_time"));
        label_time->setGeometry(QRect(190, 40, 41, 161));
        label_time->setStyleSheet(QString::fromUtf8(""));
        frame_date_1 = new QFrame(Widget);
        frame_date_1->setObjectName(QString::fromUtf8("frame_date_1"));
        frame_date_1->setGeometry(QRect(240, 20, 181, 231));
        frame_date_1->setStyleSheet(QString::fromUtf8(""));
        frame_date_1->setFrameShape(QFrame::StyledPanel);
        frame_date_1->setFrameShadow(QFrame::Raised);
        label_date_a_1 = new QLabel(frame_date_1);
        label_date_a_1->setObjectName(QString::fromUtf8("label_date_a_1"));
        label_date_a_1->setGeometry(QRect(10, 20, 51, 31));
        label_date_a_2 = new QLabel(frame_date_1);
        label_date_a_2->setObjectName(QString::fromUtf8("label_date_a_2"));
        label_date_a_2->setGeometry(QRect(10, 70, 51, 31));
        label_date_a_3 = new QLabel(frame_date_1);
        label_date_a_3->setObjectName(QString::fromUtf8("label_date_a_3"));
        label_date_a_3->setGeometry(QRect(10, 120, 51, 31));
        label_date_a_4 = new QLabel(frame_date_1);
        label_date_a_4->setObjectName(QString::fromUtf8("label_date_a_4"));
        label_date_a_4->setGeometry(QRect(10, 170, 51, 31));
        textEdit_a_1 = new QTextEdit(frame_date_1);
        textEdit_a_1->setObjectName(QString::fromUtf8("textEdit_a_1"));
        textEdit_a_1->setGeometry(QRect(60, 20, 104, 31));
        textEdit_a_3 = new QTextEdit(frame_date_1);
        textEdit_a_3->setObjectName(QString::fromUtf8("textEdit_a_3"));
        textEdit_a_3->setGeometry(QRect(60, 120, 104, 31));
        textEdit_a_2 = new QTextEdit(frame_date_1);
        textEdit_a_2->setObjectName(QString::fromUtf8("textEdit_a_2"));
        textEdit_a_2->setGeometry(QRect(60, 70, 104, 31));
        textEdit_a_4 = new QTextEdit(frame_date_1);
        textEdit_a_4->setObjectName(QString::fromUtf8("textEdit_a_4"));
        textEdit_a_4->setGeometry(QRect(60, 170, 104, 31));
        frame_date_2 = new QFrame(Widget);
        frame_date_2->setObjectName(QString::fromUtf8("frame_date_2"));
        frame_date_2->setGeometry(QRect(470, 20, 181, 231));
        frame_date_2->setStyleSheet(QString::fromUtf8(""));
        frame_date_2->setFrameShape(QFrame::StyledPanel);
        frame_date_2->setFrameShadow(QFrame::Raised);
        label_date_b_1 = new QLabel(frame_date_2);
        label_date_b_1->setObjectName(QString::fromUtf8("label_date_b_1"));
        label_date_b_1->setGeometry(QRect(10, 20, 51, 31));
        label_date_b_2 = new QLabel(frame_date_2);
        label_date_b_2->setObjectName(QString::fromUtf8("label_date_b_2"));
        label_date_b_2->setGeometry(QRect(10, 70, 51, 31));
        label_date_b_3 = new QLabel(frame_date_2);
        label_date_b_3->setObjectName(QString::fromUtf8("label_date_b_3"));
        label_date_b_3->setGeometry(QRect(10, 120, 51, 31));
        label_date_b_4 = new QLabel(frame_date_2);
        label_date_b_4->setObjectName(QString::fromUtf8("label_date_b_4"));
        label_date_b_4->setGeometry(QRect(10, 170, 51, 31));
        textEdit_b_1 = new QTextEdit(frame_date_2);
        textEdit_b_1->setObjectName(QString::fromUtf8("textEdit_b_1"));
        textEdit_b_1->setGeometry(QRect(60, 20, 104, 31));
        textEdit_b_2 = new QTextEdit(frame_date_2);
        textEdit_b_2->setObjectName(QString::fromUtf8("textEdit_b_2"));
        textEdit_b_2->setGeometry(QRect(60, 70, 104, 31));
        textEdit_b_3 = new QTextEdit(frame_date_2);
        textEdit_b_3->setObjectName(QString::fromUtf8("textEdit_b_3"));
        textEdit_b_3->setGeometry(QRect(60, 120, 104, 31));
        textEdit_b_4 = new QTextEdit(frame_date_2);
        textEdit_b_4->setObjectName(QString::fromUtf8("textEdit_b_4"));
        textEdit_b_4->setGeometry(QRect(60, 170, 104, 31));
        frame_date_3 = new QFrame(Widget);
        frame_date_3->setObjectName(QString::fromUtf8("frame_date_3"));
        frame_date_3->setGeometry(QRect(700, 20, 181, 231));
        frame_date_3->setStyleSheet(QString::fromUtf8(""));
        frame_date_3->setFrameShape(QFrame::StyledPanel);
        frame_date_3->setFrameShadow(QFrame::Raised);
        label_date_c_1 = new QLabel(frame_date_3);
        label_date_c_1->setObjectName(QString::fromUtf8("label_date_c_1"));
        label_date_c_1->setGeometry(QRect(10, 20, 51, 31));
        label_date_c_2 = new QLabel(frame_date_3);
        label_date_c_2->setObjectName(QString::fromUtf8("label_date_c_2"));
        label_date_c_2->setGeometry(QRect(10, 70, 51, 31));
        label_date_c_3 = new QLabel(frame_date_3);
        label_date_c_3->setObjectName(QString::fromUtf8("label_date_c_3"));
        label_date_c_3->setGeometry(QRect(10, 120, 51, 31));
        label_date_c_4 = new QLabel(frame_date_3);
        label_date_c_4->setObjectName(QString::fromUtf8("label_date_c_4"));
        label_date_c_4->setGeometry(QRect(10, 170, 51, 31));
        textEdit_c_1 = new QTextEdit(frame_date_3);
        textEdit_c_1->setObjectName(QString::fromUtf8("textEdit_c_1"));
        textEdit_c_1->setGeometry(QRect(60, 20, 104, 31));
        textEdit_c_2 = new QTextEdit(frame_date_3);
        textEdit_c_2->setObjectName(QString::fromUtf8("textEdit_c_2"));
        textEdit_c_2->setGeometry(QRect(60, 70, 104, 31));
        textEdit_c_3 = new QTextEdit(frame_date_3);
        textEdit_c_3->setObjectName(QString::fromUtf8("textEdit_c_3"));
        textEdit_c_3->setGeometry(QRect(60, 120, 104, 31));
        textEdit_c_4 = new QTextEdit(frame_date_3);
        textEdit_c_4->setObjectName(QString::fromUtf8("textEdit_c_4"));
        textEdit_c_4->setGeometry(QRect(60, 170, 104, 31));
        frame_a_1 = new QFrame(Widget);
        frame_a_1->setObjectName(QString::fromUtf8("frame_a_1"));
        frame_a_1->setGeometry(QRect(160, 280, 80, 80));
        frame_a_1->setStyleSheet(QString::fromUtf8(""));
        frame_a_1->setFrameShape(QFrame::StyledPanel);
        frame_a_1->setFrameShadow(QFrame::Raised);
        label_a_1 = new QLabel(frame_a_1);
        label_a_1->setObjectName(QString::fromUtf8("label_a_1"));
        label_a_1->setGeometry(QRect(20, 10, 50, 30));
        label_a_2 = new QLabel(frame_a_1);
        label_a_2->setObjectName(QString::fromUtf8("label_a_2"));
        label_a_2->setGeometry(QRect(20, 40, 50, 30));
        set_a = new QPushButton(Widget);
        set_a->setObjectName(QString::fromUtf8("set_a"));
        set_a->setGeometry(QRect(290, 280, 80, 80));
        set_a->setFont(font);
        set_a->setIconSize(QSize(16, 16));
        set_b = new QPushButton(Widget);
        set_b->setObjectName(QString::fromUtf8("set_b"));
        set_b->setGeometry(QRect(520, 280, 80, 80));
        set_b->setFont(font);
        set_b->setIconSize(QSize(16, 16));
        set_c = new QPushButton(Widget);
        set_c->setObjectName(QString::fromUtf8("set_c"));
        set_c->setGeometry(QRect(750, 280, 80, 80));
        set_c->setFont(font);
        set_c->setIconSize(QSize(16, 16));
        textEdit = new QTextEdit(Widget);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(210, 370, 620, 120));
        textEdit->setFont(font);
        textEdit->setStyleSheet(QString::fromUtf8(""));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QCoreApplication::translate("Widget", "\345\267\245\344\270\232\347\211\251\350\201\224\347\275\221", nullptr));
        back_label->setText(QString());
        label->setText(QString());
        pushButton_begin->setText(QCoreApplication::translate("Widget", "\345\274\200\345\247\213", nullptr));
        pushButton_off->setText(QCoreApplication::translate("Widget", "\345\205\263\351\227\255", nullptr));
        pushButton_temp->setText(QCoreApplication::translate("Widget", "\346\270\251\345\272\246", nullptr));
        pushButton_hum->setText(QCoreApplication::translate("Widget", "\346\271\277\345\272\246", nullptr));
        pushButton_ppm->setText(QCoreApplication::translate("Widget", "\345\205\211\345\274\2721", nullptr));
        pushButton_fire->setText(QCoreApplication::translate("Widget", "\345\205\211\345\274\2722", nullptr));
        pushButton_history->setText(QCoreApplication::translate("Widget", "\345\216\206\345\217\262\346\225\260\346\215\256", nullptr));
        pushButton_log->setText(QCoreApplication::translate("Widget", "\346\227\245\345\277\227\346\237\245\350\257\242", nullptr));
        label_time->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\345\256\236</span></p><p><span style=\" font-size:14pt;\">\346\227\266</span></p><p><span style=\" font-size:14pt;\">\346\225\260</span></p><p><span style=\" font-size:14pt;\">\346\215\256</span></p></body></html>", nullptr));
        label_date_a_1->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\346\270\251\345\272\246:</span></p></body></html>", nullptr));
        label_date_a_2->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\346\271\277\345\272\246:</span></p></body></html>", nullptr));
        label_date_a_3->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\345\205\211\345\274\2721:</span></p><p><br/></p></body></html>", nullptr));
        label_date_a_4->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\345\205\211\345\274\2722:</span></p></body></html>", nullptr));
        label_date_b_1->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\346\270\251\345\272\246:</span></p></body></html>", nullptr));
        label_date_b_2->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\346\271\277\345\272\246:</span></p></body></html>", nullptr));
        label_date_b_3->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\345\205\211\345\274\2721:</span></p></body></html>", nullptr));
        label_date_b_4->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\345\205\211\345\274\2722:</span></p></body></html>", nullptr));
        label_date_c_1->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\346\270\251\345\272\246:</span></p></body></html>", nullptr));
        label_date_c_2->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\346\271\277\345\272\246:</span></p></body></html>", nullptr));
        label_date_c_3->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\345\205\211\345\274\2721:</span></p></body></html>", nullptr));
        label_date_c_4->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\345\205\211\345\274\2722:</span></p></body></html>", nullptr));
        label_a_1->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\350\212\202\347\202\271</span></p></body></html>", nullptr));
        label_a_2->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\347\212\266\346\200\201</span></p></body></html>", nullptr));
        set_a->setText(QCoreApplication::translate("Widget", "\350\212\202\347\202\2711", nullptr));
        set_b->setText(QCoreApplication::translate("Widget", "\350\212\202\347\202\2712", nullptr));
        set_c->setText(QCoreApplication::translate("Widget", "\350\212\202\347\202\2713", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
