#include "widget.h"
#include "ui_widget.h"
#include <QFile>
#include <QFileDialog>
#include <QDateTime>

QTimer *set_ch_1 = new QTimer();
QTimer *set_ch_2 = new QTimer();
QTimer *set_ch_3 = new QTimer();
QTimer *check = new QTimer();       //在线检查定时器

QList<double> data_temp_1;              //temp列表
QList<double> data_temp_2;
QList<double> data_temp_3;

QList<double> data_hum_1;              //hum列表
QList<double> data_hum_2;
QList<double> data_hum_3;

QList<double> data_ppm_1;              //ppm列表
QList<double> data_ppm_2;
QList<double> data_ppm_3;

QList<double> data_fire_1;              //ppm列表
QList<double> data_fire_2;
QList<double> data_fire_3;

int set_1 = 0, set_2 = 0, set_3 = 0;
int flag_1 = 0,flag_2 = 0,flag_3 = 0;
Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    ui->set_a->setStyleSheet("border:5px solid rgb(0, 176, 240)");
    ui->set_b->setStyleSheet("border:5px solid rgb(0, 176, 240)");
    ui->set_c->setStyleSheet("border:5px solid rgb(0, 176, 240)");
    serialPort = new QSerialPort(this);
    set_ch_1->start(5000);//5秒钟
    set_ch_2->start(5000);
    set_ch_3->start(5000);
    check->start(500);

    connect(serialPort, SIGNAL(readyRead()),                //信号与槽连接
            this, SLOT(serialPortReadyRead()));

    connect(set_ch_1, SIGNAL(timeout()),
            this, SLOT(timer_ch_1()));

    connect(set_ch_2, SIGNAL(timeout()),
            this, SLOT(timer_ch_2()));

    connect(check, SIGNAL(timeout()),
            this, SLOT(timer_check()));

    connect(set_ch_3, SIGNAL(timeout()),
            this, SLOT(timer_ch_3()));
}

Widget::~Widget()
{
    delete ui;
}

/********************************
普通函数
********************************/
void Widget::openSerial()
{
    serialPort->setPortName("ttyS1");
    serialPort->setBaudRate(QSerialPort::Baud115200);
    serialPort->setDataBits(QSerialPort::Data8);
    serialPort->setParity(QSerialPort::NoParity);
    serialPort->setStopBits(QSerialPort::OneStop);
    serialPort->setFlowControl(QSerialPort::NoFlowControl);
    serialPort->open(QIODevice::ReadWrite);
}

void Widget::dataHandle(QByteArray &data)
{
    QJsonParseError json_error;
    QJsonDocument jsonDoc(QJsonDocument::fromJson(data, &json_error));
    if(json_error.error != QJsonParseError::NoError)
    {
        return ;
    }
    QJsonObject rootObj = jsonDoc.object();
    QStringList keys = rootObj.keys();
    QJsonValue ID = rootObj.value("ID");
    int id = ID.toInt();
    double temp_x = 0;
    double hum_x = 0;
    double ppm_x = 0;
    double fire_x = 0;
    if(id == 1)
    {
        set_1 =1;
        set_ch_1->setInterval(8000);    //重开定时器
        set_ch_1->start();

        QDateTime current_date_time =QDateTime::currentDateTime();

        if(flag_1 == 1)
        {
            QDateTime current_date_time =QDateTime::currentDateTime();
            QString str = current_date_time .toString("yyyy-MM-dd hh:mm:ss") + "节点1  上线"+"\n";//格式化时间

            QString filepath = QCoreApplication::applicationDirPath();
            QFile *file = new QFile(filepath + "/2.txt");
            file->open(QIODevice::Append);
            file->write(str.toUtf8());
            file->close();
        }
        flag_1 = 0;

        QJsonValue Temp = rootObj.value("Tempeture");
        double temp = Temp.toDouble();
        temp_x = temp;
        QString temp_text = QString::number(temp)+"℃";
        ui->textEdit_a_1->setText(temp_text);
        QString warning_text;
        if(temp > 30)
        {
            warning_text = current_date_time.toString("yyyy-MM-dd hh:mm:ss") + "节点1温度过高";

            ui->textEdit->append(warning_text);
        }
        else if(temp < 20)
        {
            warning_text = current_date_time.toString("yyyy-MM-dd hh:mm:ss") + "节点1温度过低";
            ui->textEdit->append(warning_text);
        }

        QJsonValue Hum = rootObj.value("Humidity");
        double hum = Hum.toDouble();
        hum_x = hum;
        QString hum_text = QString::number(hum)+"%RH";
        ui->textEdit_a_2->setText(hum_text);
        if(hum > 65)
        {
            warning_text = current_date_time.toString("yyyy-MM-dd hh:mm:ss") + "节点1湿度过高";
            ui->textEdit->append(warning_text);
        }
        else if(hum < 30)
        {
            warning_text = current_date_time.toString("yyyy-MM-dd hh:mm:ss") + "节点1湿度过低";
            ui->textEdit->append(warning_text);
        }

        QJsonValue Smoke = rootObj.value("Smoke");
        double smoke = Smoke.toDouble();
        ppm_x = smoke;
        QString smoke_text = QString::number(smoke);
        ui->textEdit_a_3->setText(smoke_text);

        QJsonValue Fire = rootObj.value("Fire");
        double fire = Fire.toDouble();
        fire_x = fire;
        QString fire_text = QString::number(fire);
        ui->textEdit_a_4->setText(fire_text);


        QString str = current_date_time .toString("yyyy-MM-dd hh:mm:ss") + "节点1 "+
                " 温度 "+temp_text+" 湿度 "+hum_text+" 光强1 "+smoke_text +" 光强2 "+fire_text+"\n";
        QString filepath = QCoreApplication::applicationDirPath();
        QFile *file = new QFile(filepath + "/1.txt");
        file->open(QIODevice::Append);
        file->write(str.toUtf8());
        file->close();
    }
    if(id == 2)
    {
        set_2 =1;
        set_ch_2->setInterval(8000);    //调节
        set_ch_2->start();
        QDateTime current_date_time =QDateTime::currentDateTime();
        if(flag_2 == 1)
        {
            QDateTime current_date_time =QDateTime::currentDateTime();
            QString str = current_date_time .toString("yyyy-MM-dd hh:mm:ss") + "节点2  上线"+"\n";//格式化时间

            QString filepath = QCoreApplication::applicationDirPath();
            QFile *file = new QFile(filepath + "/2.txt");
            file->open(QIODevice::Append);
            file->write(str.toUtf8());
            file->close();
        }
        flag_2 = 0;

        QJsonValue Temp = rootObj.value("Tempeture");
        double temp = Temp.toDouble();
        temp_x = temp;
        QString temp_text = QString::number(temp)+"℃";
        ui->textEdit_b_1->setText(temp_text);
        QString warning_text;
        if(temp > 30)
        {
            warning_text = current_date_time.toString("yyyy-MM-dd hh:mm:ss") + "节点2温度过高";
            ui->textEdit->append(warning_text);
        }
        else if(temp < 20)
        {
            warning_text = current_date_time.toString("yyyy-MM-dd hh:mm:ss") + "节点2温度过低";
            ui->textEdit->append(warning_text);
        }

        QJsonValue Hum = rootObj.value("Humidity");
        double hum = Hum.toDouble();
        hum_x = hum;
        QString hum_text = QString::number(hum)+"%RH";
        ui->textEdit_b_2->setText(hum_text);
        if(hum > 65)
        {
            warning_text = current_date_time.toString("yyyy-MM-dd hh:mm:ss") + "节点2湿度过高";
            ui->textEdit->append(warning_text);
        }
        else if(hum < 30)
        {
            warning_text = current_date_time.toString("yyyy-MM-dd hh:mm:ss") + "节点2湿度过低";
            ui->textEdit->append(warning_text);
        }

        QJsonValue Smoke = rootObj.value("Smoke");
        double smoke = Smoke.toDouble();
        ppm_x = smoke;
        QString smoke_text = QString::number(smoke);
        ui->textEdit_b_3->setText(smoke_text);


        QJsonValue Fire = rootObj.value("Fire");
        double fire = Fire.toDouble();
        fire_x = fire;
        QString fire_text = QString::number(fire);
        ui->textEdit_b_4->setText(fire_text);


        QString str = current_date_time .toString("yyyy-MM-dd hh:mm:ss") + "节点2 "+
                " 温度 "+temp_text+" 湿度 "+hum_text+" 光强1 "+smoke_text +" 光强2 "+fire_text+"\n";
        QString filepath = QCoreApplication::applicationDirPath();
        QFile *file = new QFile(filepath + "/1.txt");
        file->open(QIODevice::Append);
        file->write(str.toUtf8());
        file->close();
    }
    if(id == 3)
    {
        set_3 =1;
        set_ch_3->setInterval(8000);
        set_ch_3->start();
        QDateTime current_date_time =QDateTime::currentDateTime();

        if(flag_3 == 1)
        {
            QDateTime current_date_time =QDateTime::currentDateTime();
            QString str = current_date_time .toString("yyyy-MM-dd hh:mm:ss") + "节点3  上线"+"\n";//格式化时间

            QString filepath = QCoreApplication::applicationDirPath();
            QFile *file = new QFile(filepath + "/2.txt");
            file->open(QIODevice::Append);
            file->write(str.toUtf8());
            file->close();
        }
        flag_3 = 0;

        QJsonValue Temp = rootObj.value("Tempeture");
        double temp = Temp.toDouble();
        temp_x = temp;
        QString temp_text = QString::number(temp)+"℃";
        ui->textEdit_c_1->setText(temp_text);
        QString warning_text;
        if(temp > 30)
        {
            warning_text = current_date_time.toString("yyyy-MM-dd hh:mm:ss") + "节点3温度过高";
            ui->textEdit->append(warning_text);
        }
        else if(temp < 20)
        {
            warning_text = current_date_time.toString("yyyy-MM-dd hh:mm:ss") + "节点3温度过低";
            ui->textEdit->append(warning_text);
        }

        QJsonValue Hum = rootObj.value("Humidity");
        double hum = Hum.toDouble();
        hum_x = hum;
        QString hum_text = QString::number(hum)+"%RH";
        ui->textEdit_c_2->setText(hum_text);
        if(hum > 65)
        {
            warning_text = current_date_time.toString("yyyy-MM-dd hh:mm:ss") + "节点3湿度过高";
            ui->textEdit->append(warning_text);
        }
        else if(hum < 30)
        {
            warning_text = current_date_time.toString("yyyy-MM-dd hh:mm:ss") + "节点3湿度过低";
            ui->textEdit->append(warning_text);
        }

        QJsonValue Smoke = rootObj.value("Smoke");
        double smoke = Smoke.toDouble();
        ppm_x = smoke;
        QString smoke_text = QString::number(smoke);
        ui->textEdit_c_3->setText(smoke_text);


        QJsonValue Fire = rootObj.value("Fire");
        double fire = Fire.toDouble();
        fire_x = fire;
        QString fire_text = QString::number(fire);
        ui->textEdit_c_4->setText(fire_text);


        QString str = current_date_time .toString("yyyy-MM-dd hh:mm:ss") + "节点3 "+
                " 温度 "+temp_text+" 湿度 "+hum_text+" 光强1 "+smoke_text +" 光强2 "+fire_text+"\n";
        QString filepath = QCoreApplication::applicationDirPath();
        QFile *file = new QFile(filepath + "/1.txt");
        file->open(QIODevice::Append);
        file->write(str.toUtf8());
        file->close();
    }
    dataTransmission(id, temp_x, hum_x, ppm_x, fire_x);
}

void Widget::checkOnline()
{
    if(set_1 == 1)
        ui->set_a->setStyleSheet("border:5px solid rgb(0, 176, 240);background-color:rgb(0, 176, 240)");
    else
    {
        ui->set_a->setStyleSheet("border:5px solid rgb(0, 176, 240);background-color:rgb(255, 255, 255)");
        ui->textEdit_a_1->clear();
        ui->textEdit_a_2->clear();
        ui->textEdit_a_3->clear();
        ui->textEdit_a_4->clear();
    }

    if(set_2 == 1)
        ui->set_b->setStyleSheet("border:5px solid rgb(0, 176, 240);background-color:rgb(0, 176, 240)");
    else
    {
        ui->set_b->setStyleSheet("border:5px solid rgb(0, 176, 240);background-color:rgb(255, 255, 255)");
        ui->textEdit_b_1->clear();
        ui->textEdit_b_2->clear();
        ui->textEdit_b_3->clear();
        ui->textEdit_b_4->clear();
    }

    if(set_3 == 1)
        ui->set_c->setStyleSheet("border:5px solid rgb(0, 176, 240);background-color:rgb(0, 176, 240)");
    else
    {
        ui->set_c->setStyleSheet("border:5px solid rgb(0, 176, 240);background-color:rgb(255, 255, 255)");
        ui->textEdit_c_1->clear();
        ui->textEdit_c_2->clear();
        ui->textEdit_c_3->clear();
        ui->textEdit_c_4->clear();
    }
}

void Widget::dataTransmission(int id, double temp_x, double hum_x, double ppm_x, double fire_x)
{
    double temp_l,hum_l,ppm_l,fire_l;
    /***********************************************/
    if(data_temp_1.isEmpty())
        temp_l = 0;
    else
        temp_l = data_temp_1.last();
    if(set_1 == 1 && id == 1)
        data_temp_1.append(temp_x);
    else if(set_1 &&(id == 2 || id == 3))
        data_temp_1.append(temp_l);
    else if(set_1 == 0)
        data_temp_1.append(0);
    while(data_temp_1.size() > 51)
        data_temp_1.removeFirst();

    if(data_temp_2.isEmpty())
        temp_l = 0;
    else
        temp_l = data_temp_2.last();
    if(set_2 == 1 && id == 2)
        data_temp_2.append(temp_x);
    else if(set_2 &&(id == 1 || id == 3))
        data_temp_2.append(temp_l);
    else if(set_2 == 0)
        data_temp_2.append(0);
    while(data_temp_2.size() > 51)
        data_temp_2.removeFirst();

    if(data_temp_3.isEmpty())
        temp_l = 0;
    else
        temp_l = data_temp_3.last();
    if(set_3 == 1 && id == 3)
        data_temp_3.append(temp_x);
    else if(set_3 &&(id == 1 || id == 2))
        data_temp_3.append(temp_l);
    else if(set_3 == 0)
        data_temp_3.append(0);
    while(data_temp_3.size() > 51)
        data_temp_3.removeFirst();
    /********************************************/
    if(data_hum_1.isEmpty())
        hum_l = 0;
    else
        hum_l = data_hum_1.last();
    if(set_1 == 1 && id == 1)
        data_hum_1.append(hum_x);
    else if(set_1 &&(id == 2 || id == 3))
        data_hum_1.append(hum_l);
    else if(set_1 == 0)
        data_hum_1.append(0);
    while(data_hum_1.size() > 51)
        data_hum_1.removeFirst();

    if(data_hum_2.isEmpty())
        hum_l = 0;
    else
        hum_l = data_hum_2.last();
    if(set_2 == 1 && id == 2)
        data_hum_2.append(hum_x);
    else if(set_2 &&(id == 1 || id == 3))
        data_hum_2.append(hum_l);
    else if(set_2 == 0)
        data_hum_2.append(0);
    while(data_hum_2.size() > 51)
        data_hum_2.removeFirst();

    if(data_hum_3.isEmpty())
        hum_l = 0;
    else
        hum_l = data_hum_3.last();
    if(set_3 == 1 && id == 3)
        data_hum_3.append(hum_x);
    else if(set_3 &&(id == 1 || id == 2))
        data_hum_3.append(hum_l);
    else if(set_3 == 0)
        data_hum_3.append(0);
    while(data_hum_3.size() > 51)
        data_hum_3.removeFirst();
    /************************************************/
    if(data_ppm_1.isEmpty())
        ppm_l = 0;
    else
        ppm_l = data_ppm_1.last();
    if(set_1 == 1 && id == 1)
        data_ppm_1.append(ppm_x);
    else if(set_1 &&(id == 2 || id == 3))
        data_ppm_1.append(ppm_l);
    else if(set_1 == 0)
        data_ppm_1.append(0);
    while(data_ppm_1.size() > 51)
        data_ppm_1.removeFirst();

    if(data_ppm_2.isEmpty())
        ppm_l = 0;
    else
        ppm_l = data_ppm_2.last();
    if(set_2 == 1 && id == 2)
        data_ppm_2.append(ppm_x);
    else if(set_2 &&(id == 1 || id == 3))
        data_ppm_2.append(ppm_l);
    else if(set_2 == 0)
        data_ppm_2.append(0);
    while(data_ppm_2.size() > 51)
        data_ppm_2.removeFirst();

    if(data_ppm_3.isEmpty())
        ppm_l = 0;
    else
        ppm_l = data_ppm_3.last();
    if(set_3 == 1 && id == 3)
        data_ppm_3.append(hum_x);
    else if(set_3 &&(id == 1 || id == 2))
        data_ppm_3.append(ppm_l);
    else if(set_3 == 0)
        data_ppm_3.append(0);
    while(data_ppm_3.size() > 51)
        data_ppm_3.removeFirst();
    /***********************************************/
    if(data_fire_1.isEmpty())
        fire_l = 0;
    else
        fire_l = data_fire_1.last();
    if(set_1 == 1 && id == 1)
        data_fire_1.append(fire_x);
    else if(set_1 &&(id == 2 || id == 3))
        data_fire_1.append(fire_l);
    else if(set_1 == 0)
        data_fire_1.append(0);
    while(data_fire_1.size() > 51)
        data_fire_1.removeFirst();

    if(data_fire_2.isEmpty())
        fire_l = 0;
    else
        fire_l = data_fire_2.last();
    if(set_2 == 1 && id == 2)
        data_fire_2.append(ppm_x);
    else if(set_2 &&(id == 1 || id == 3))
        data_fire_2.append(ppm_l);
    else if(set_2 == 0)
        data_fire_2.append(0);
    while(data_fire_2.size() > 51)
        data_fire_2.removeFirst();

    if(data_fire_3.isEmpty())
        fire_l = 0;
    else
        fire_l = data_fire_3.last();
    if(set_3 == 1 && id == 3)
        data_fire_3.append(fire_x);
    else if(set_3 &&(id == 1 || id == 2))
        data_fire_3.append(fire_l);
    else if(set_3 == 0)
        data_fire_3.append(0);
    while(data_fire_3.size() > 51)
        data_fire_3.removeFirst();

}
/********************************
槽函数
********************************/
void Widget::on_pushButton_begin_clicked()
{
    openSerial();
}

void Widget::serialPortReadyRead()
{
    buf = serialPort->readAll();
    if(!buf.isEmpty())
    {
        buf_1.append(buf);
        if(buf_1.contains("}"))
        {
            dataHandle(buf_1);
            serialPort->write(buf_1);
            buf_1.clear();
        }
    }
    buf.clear();
}

/****************************/
void Widget::timer_ch_1()
{
    set_1 = 0;
    if(flag_1 == 0)
    {
        QDateTime current_date_time =QDateTime::currentDateTime();
        QString str = current_date_time .toString("yyyy-MM-dd hh:mm:ss") + "节点1  下线"+"\n";//格式化时间

        QString filepath = QCoreApplication::applicationDirPath();
        QFile *file = new QFile(filepath + "/2.txt");
        file->open(QIODevice::Append);
        file->write(str.toUtf8());
        file->close();
    }
    flag_1 = 1;

}
void Widget::timer_ch_2()
{
    set_2 = 0;
    if(flag_2 == 0)
    {
        QDateTime current_date_time =QDateTime::currentDateTime();
        QString str = current_date_time .toString("yyyy-MM-dd hh:mm:ss") + "节点2  下线"+"\n";//格式化时间

        QString filepath = QCoreApplication::applicationDirPath();
        QFile *file = new QFile(filepath + "/2.txt");
        file->open(QIODevice::Append);
        file->write(str.toUtf8());
        file->close();
    }
    flag_2 = 1;
}
void Widget::timer_ch_3()
{
    set_3 = 0;
    if(flag_3 == 0)
    {
        QDateTime current_date_time =QDateTime::currentDateTime();
        QString str = current_date_time .toString("yyyy-MM-dd hh:mm:ss") + "节点3  下线"+"\n";//格式化时间

        QString filepath = QCoreApplication::applicationDirPath();
        QFile *file = new QFile(filepath + "/2.txt");
        file->open(QIODevice::Append);
        file->write(str.toUtf8());
        file->close();
    }
    flag_3 = 1;
}
void Widget::timer_check()
{
    checkOnline();
}
/**************************/
void Widget::on_pushButton_off_clicked()
{
    this->close();
}

void Widget::on_pushButton_temp_clicked()
{
    FormTemp *Temp = new FormTemp();
    Temp->show();
}
void Widget::on_pushButton_hum_clicked()
{
    FormHum *Hum = new FormHum();
    Hum->show();
}

void Widget::on_pushButton_ppm_clicked()
{
    FormPpm *Ppm = new FormPpm();
    Ppm->show();
}

void Widget::on_pushButton_fire_clicked()
{
    FormFire *Fire = new FormFire();
    Fire->show();
}

void Widget::on_pushButton_history_clicked()
{
    FormHisData *HisData = new FormHisData();
    HisData->show();
}

void Widget::on_pushButton_log_clicked()
{
    FormHisLog *HisLog = new FormHisLog();
    HisLog->show();
}
